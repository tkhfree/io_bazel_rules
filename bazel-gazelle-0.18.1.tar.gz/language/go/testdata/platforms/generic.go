package platforms

import _ "example.com/repo/platforms/generic"
