package platforms

import (
	_ "example.com/repo/platforms/darwin"
	_ "example.com/repo/platforms/generic"
)
