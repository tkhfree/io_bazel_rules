#define FOOVAL 42
