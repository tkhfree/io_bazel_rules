// +build !race

package race

const goRaceEnabled = false
