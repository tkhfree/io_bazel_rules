// +build !race

int race_enabled = 0;
