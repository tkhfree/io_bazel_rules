// +build !cgo

package main

// this file should not be compiled
!!!
