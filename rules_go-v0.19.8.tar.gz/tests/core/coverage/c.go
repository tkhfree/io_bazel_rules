package c

func CLive() int {
	return 12
}

func CDead() int {
	return 34
}
