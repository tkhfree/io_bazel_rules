package dep

// visibility:noerrors
func D() {
}
