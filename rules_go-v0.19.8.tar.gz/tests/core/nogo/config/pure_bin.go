package main

import _ "github.com/bazelbuild/rules_go/tests/core/nogo/config/pure_lib"

func main() {
}
