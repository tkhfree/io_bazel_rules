package main

import (
	_ "golang.org/x/sys/unix" // See https://github.com/bazelbuild/rules_go/issues/2168
)

func main() {}
