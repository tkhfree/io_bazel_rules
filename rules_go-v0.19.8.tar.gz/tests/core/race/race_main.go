package main

import (
	"github.com/bazelbuild/rules_go/tests/core/race"
)

func main() {
	race.TriggerRace()
}
