// +build race

package racy

const RaceEnabled = true
